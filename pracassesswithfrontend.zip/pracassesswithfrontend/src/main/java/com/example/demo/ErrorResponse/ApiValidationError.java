package com.example.demo.ErrorResponse;

import java.io.Serializable;

public class ApiValidationError extends ApiSubError implements Serializable {
	
	private static final long serialVersionID=1L;
	private String object;
	private String field;
	private Object rejectedValue;
	private String messge;
	public ApiValidationError(String object, String field, Object rejectedValue, String message) {
		super();
		this.object=object;
		this.field=field;
		this.messge= message;
		this.rejectedValue= rejectedValue;
	}
	

}
