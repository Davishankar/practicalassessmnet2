package com.example.demo.ErrorResponse;

import java.io.Serializable;

public class ApiSubError implements Serializable {

	private static final long serialVersionID=1L;
}
