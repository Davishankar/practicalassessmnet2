package com.example.demo.ErrorResponse;

public class ApiError {

}
